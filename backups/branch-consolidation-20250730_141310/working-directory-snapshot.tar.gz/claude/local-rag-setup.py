#!/usr/bin/env python3
"""
Local RAG System for Claude Code
Optimized for homelab infrastructure codebases with local embeddings
"""

import os
import json
import sqlite3
import hashlib
import argparse
from pathlib import Path
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from datetime import datetime

# Local embedding libraries with GPU safety
try:
    import sentence_transformers
    from sentence_transformers import SentenceTransformer
    import numpy as np
    import faiss
    import torch
    import psutil
    import GPUtil
    import threading
    import time
    from concurrent.futures import ThreadPoolExecutor
    HAS_LOCAL_EMBEDDINGS = True
    
    # Check for GPU availability
    HAS_GPU = torch.cuda.is_available()
    GPU_COUNT = torch.cuda.device_count() if HAS_GPU else 0
    
    # Try to import optional performance libraries
    try:
        import cupy as cp
        HAS_CUPY = True
    except ImportError:
        HAS_CUPY = False
    
    try:
        import faiss_gpu
        HAS_FAISS_GPU = True
    except ImportError:
        HAS_FAISS_GPU = False
    
except ImportError as e:
    print(f"⚠️  Install dependencies: pip install sentence-transformers faiss-cpu numpy torch GPUtil psutil")
    print(f"   Missing: {e}")
    HAS_LOCAL_EMBEDDINGS = False
    HAS_GPU = False
    GPU_COUNT = 0
    HAS_CUPY = False
    HAS_FAISS_GPU = False

class GPUMonitor:
    """Safe GPU monitoring and thermal management"""
    
    def __init__(self):
        self.monitoring = False
        self.max_temp = 80.0  # Conservative temperature limit
        self.max_memory_usage = 0.85  # 85% memory usage limit
        self.monitoring_thread = None
        self.safety_callback = None
        
    def start_monitoring(self, callback=None):
        """Start continuous GPU monitoring"""
        if not HAS_GPU:
            return
            
        self.safety_callback = callback
        self.monitoring = True
        self.monitoring_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitoring_thread.start()
        print("🛡️  GPU safety monitoring started")
    
    def stop_monitoring(self):
        """Stop GPU monitoring"""
        self.monitoring = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5)
        print("🛡️  GPU safety monitoring stopped")
    
    def _monitor_loop(self):
        """Continuous monitoring loop"""
        while self.monitoring:
            try:
                if self.check_gpu_safety():
                    time.sleep(5)  # Check every 5 seconds
                else:
                    print("⚠️  GPU safety limits exceeded - pausing operations")
                    if self.safety_callback:
                        self.safety_callback()
                    time.sleep(30)  # Wait 30 seconds before resuming
            except Exception as e:
                print(f"⚠️  GPU monitoring error: {e}")
                time.sleep(10)
    
    def check_gpu_safety(self) -> bool:
        """Check if GPU is within safe operating limits"""
        if not HAS_GPU:
            return True
        
        try:
            gpus = GPUtil.getGPUs()
            for gpu in gpus:
                # Check temperature
                if gpu.temperature > self.max_temp:
                    print(f"🔥 GPU {gpu.id} temperature: {gpu.temperature}°C (limit: {self.max_temp}°C)")
                    return False
                
                # Check memory usage
                if gpu.memoryUtil > self.max_memory_usage:
                    print(f"💾 GPU {gpu.id} memory usage: {gpu.memoryUtil*100:.1f}% (limit: {self.max_memory_usage*100:.1f}%)")
                    return False
            
            return True
        except Exception as e:
            print(f"⚠️  GPU safety check failed: {e}")
            return False
    
    def get_gpu_stats(self) -> Dict[str, Any]:
        """Get current GPU statistics"""
        if not HAS_GPU:
            return {"gpu_available": False}
        
        try:
            gpus = GPUtil.getGPUs()
            stats = {
                "gpu_available": True,
                "gpu_count": len(gpus),
                "gpus": []
            }
            
            for gpu in gpus:
                gpu_info = {
                    "id": gpu.id,
                    "name": gpu.name,
                    "temperature": gpu.temperature,
                    "memory_used": gpu.memoryUsed,
                    "memory_total": gpu.memoryTotal,
                    "memory_util": gpu.memoryUtil,
                    "load": gpu.load
                }
                stats["gpus"].append(gpu_info)
            
            return stats
        except Exception as e:
            return {"gpu_available": False, "error": str(e)}
    
    def get_optimal_batch_size(self, model_memory_mb: int = 500) -> int:
        """Calculate optimal batch size based on available GPU memory"""
        if not HAS_GPU:
            return 32  # Conservative CPU batch size
        
        try:
            gpus = GPUtil.getGPUs()
            if not gpus:
                return 32
            
            # Use the GPU with most free memory
            best_gpu = max(gpus, key=lambda g: g.memoryFree)
            free_memory_mb = best_gpu.memoryFree
            
            # Conservative calculation: leave 2GB free for safety
            safety_buffer_mb = 2048
            usable_memory_mb = max(0, free_memory_mb - safety_buffer_mb)
            
            # Estimate batch size (rough approximation)
            estimated_batch_size = max(1, int(usable_memory_mb / model_memory_mb))
            
            # Cap at reasonable limits
            return min(estimated_batch_size, 256)
            
        except Exception as e:
            print(f"⚠️  Batch size calculation failed: {e}")
            return 32

@dataclass
class CodeChunk:
    content: str
    file_path: str
    start_line: int
    end_line: int
    chunk_type: str  # function, config, comment, etc.
    priority: str    # critical, high, medium, low
    metadata: Dict[str, Any]

class LocalRAGSystem:
    def __init__(self, config_path: str = None):
        self.config_path = config_path or ".claude/rag-config.json"
        self.load_config()
        
        # Initialize local embedding model
        self.embedding_model = None
        self.vector_index = None
        self.db_path = Path(self.config.get('vector_db_path', '.claude/vectors.db'))
        self.index_path = Path(self.config.get('faiss_index_path', '.claude/faiss.index'))
        
        # GPU safety and monitoring
        self.gpu_device = None
        self.gpu_monitor = GPUMonitor()
        self.batch_size = self._calculate_safe_batch_size()
        
        # Create directories
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Initialize components
        self._init_embedding_model()
        self._init_database()
        self._init_vector_index()
    
    def load_config(self):
        """Load RAG configuration"""
        try:
            with open(self.config_path, 'r') as f:
                self.config = json.load(f)
        except FileNotFoundError:
            print(f"⚠️  Config not found: {self.config_path}")
            self.config = self._default_config()
    
    def _default_config(self) -> Dict[str, Any]:
        """Default configuration if config file not found"""
        return {
            "embedding_model": "all-MiniLM-L6-v2",
            "chunk_size": 512,
            "chunk_overlap": 50,
            "similarity_threshold": 0.75,
            "max_chunks_per_query": 5,
            "vector_db_path": ".claude/vectors.db",
            "faiss_index_path": ".claude/faiss.index"
        }
    
    def _init_embedding_model(self):
        """Initialize local embedding model with GPU safety"""
        if not HAS_LOCAL_EMBEDDINGS:
            print("❌ Local embeddings not available. Install required packages.")
            return
        
        model_name = self.config.get('embedding_model', 'all-MiniLM-L6-v2')
        use_gpu = self.config.get('use_gpu', True) and HAS_GPU
        
        print(f"🔄 Loading embedding model: {model_name}")
        
        # Display system capabilities
        if HAS_GPU:
            gpu_stats = self.gpu_monitor.get_gpu_stats()
            print(f"🖥️  GPU Available: {GPU_COUNT} device(s)")
            if gpu_stats.get("gpus"):
                for gpu in gpu_stats["gpus"]:
                    print(f"   GPU {gpu['id']}: {gpu['name']} ({gpu['memory_total']}MB)")
        else:
            print("🖥️  Using CPU for embeddings")
        
        try:
            # Determine device
            if use_gpu and HAS_GPU:
                # Check GPU safety before loading model
                if self.gpu_monitor.check_gpu_safety():
                    device = f'cuda:{self._select_best_gpu()}'
                    self.gpu_device = device
                    print(f"🚀 Using GPU device: {device}")
                    
                    # Start safety monitoring
                    self.gpu_monitor.start_monitoring(self._gpu_safety_callback)
                else:
                    device = 'cpu'
                    print("⚠️  GPU safety check failed, falling back to CPU")
            else:
                device = 'cpu'
                print("🖥️  Using CPU device")
            
            # Load model with specified device
            self.embedding_model = SentenceTransformer(model_name, device=device)
            
            # Optimize model settings
            if device != 'cpu':
                # Enable mixed precision for efficiency
                if hasattr(self.embedding_model, 'half'):
                    self.embedding_model.half()
                    print("⚡ Enabled half-precision (FP16) for GPU efficiency")
            
            print(f"✅ Embedding model loaded: {model_name} on {device}")
            
        except Exception as e:
            print(f"❌ Failed to load embedding model: {e}")
            # Fallback to CPU
            try:
                self.embedding_model = SentenceTransformer(model_name, device='cpu')
                print("✅ Fallback: Model loaded on CPU")
            except Exception as fallback_e:
                print(f"❌ Complete failure: {fallback_e}")
    
    def _select_best_gpu(self) -> int:
        """Select GPU with most available memory"""
        if not HAS_GPU:
            return 0
        
        try:
            gpus = GPUtil.getGPUs()
            if not gpus:
                return 0
            
            # Select GPU with most free memory and lowest temperature
            best_gpu = max(gpus, key=lambda g: g.memoryFree - (g.temperature * 10))
            return best_gpu.id
        except:
            return 0
    
    def _gpu_safety_callback(self):
        """Callback when GPU safety limits are exceeded"""
        if self.embedding_model and hasattr(self.embedding_model, 'device'):
            print("🛡️  Moving model to CPU due to GPU safety limits")
            try:
                self.embedding_model = self.embedding_model.to('cpu')
                self.gpu_device = 'cpu'
            except Exception as e:
                print(f"⚠️  Error moving model to CPU: {e}")
    
    def _calculate_safe_batch_size(self) -> int:
        """Calculate safe batch size for current system"""
        gpu_batch = self.gpu_monitor.get_optimal_batch_size() if HAS_GPU else 32
        
        # Also consider CPU memory
        cpu_memory_gb = psutil.virtual_memory().available / (1024**3)
        cpu_batch = max(16, min(128, int(cpu_memory_gb * 8)))  # Rough estimate
        
        # Use the more conservative option
        return min(gpu_batch, cpu_batch)
    
    def _init_database(self):
        """Initialize SQLite database for metadata"""
        self.conn = sqlite3.connect(str(self.db_path))
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS code_chunks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content_hash TEXT UNIQUE,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                chunk_type TEXT,
                priority TEXT, 
                content TEXT,
                metadata TEXT,
                embedding_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS codebase_metadata (
                codebase_name TEXT PRIMARY KEY,
                last_indexed TIMESTAMP,
                total_chunks INTEGER,
                config_hash TEXT
            )
        ''')
        
        self.conn.commit()
        print("✅ Database initialized")
    
    def _init_vector_index(self):
        """Initialize FAISS vector index"""
        if not HAS_LOCAL_EMBEDDINGS:
            return
        
        embedding_dim = 384  # all-MiniLM-L6-v2 dimension
        
        if self.index_path.exists():
            try:
                self.vector_index = faiss.read_index(str(self.index_path))
                print(f"✅ Loaded existing FAISS index: {self.vector_index.ntotal} vectors")
            except Exception as e:
                print(f"⚠️  Failed to load existing index: {e}")
                self.vector_index = faiss.IndexFlatIP(embedding_dim)
        else:
            self.vector_index = faiss.IndexFlatIP(embedding_dim)
            print("✅ Created new FAISS index")
    
    def chunk_code_file(self, file_path: str) -> List[CodeChunk]:
        """Intelligently chunk a code file based on structure"""
        chunks = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
        except Exception as e:
            print(f"⚠️  Failed to read {file_path}: {e}")
            return chunks
        
        # Detect file type and prioritization
        priority = self._get_file_priority(file_path)
        codebase_type = self._detect_codebase_type(file_path)
        
        # Function-based chunking for shell scripts and similar
        if file_path.endswith(('.sh', '.py', '.js', '.ts')):
            chunks.extend(self._chunk_by_functions(lines, file_path, priority))
        
        # Configuration block chunking for YAML/JSON/TF
        elif file_path.endswith(('.yaml', '.yml', '.json', '.tf')):
            chunks.extend(self._chunk_by_config_blocks(lines, file_path, priority))
        
        # Documentation chunking for markdown
        elif file_path.endswith('.md'):
            chunks.extend(self._chunk_by_sections(lines, file_path, priority))
        
        # Fallback: sliding window chunking
        else:
            chunks.extend(self._chunk_by_sliding_window(lines, file_path, priority))
        
        return chunks
    
    def _chunk_by_functions(self, lines: List[str], file_path: str, priority: str) -> List[CodeChunk]:
        """Chunk by function boundaries"""
        chunks = []
        current_chunk = []
        current_start = 0
        in_function = False
        brace_count = 0
        
        for i, line in enumerate(lines):
            current_chunk.append(line)
            
            # Detect function start
            if any(pattern in line for pattern in ['function ', '() {', 'def ', 'class ']):
                if current_chunk and not in_function:
                    # Save previous chunk
                    if len(current_chunk) > 1:
                        chunks.append(self._create_chunk(
                            current_chunk[:-1], file_path, current_start, i-1, 
                            'general', priority
                        ))
                    current_chunk = [line]
                    current_start = i
                in_function = True
            
            # Track braces for shell functions
            if '{' in line:
                brace_count += line.count('{')
            if '}' in line:
                brace_count -= line.count('}')
                if brace_count <= 0 and in_function:
                    # Function ended
                    chunks.append(self._create_chunk(
                        current_chunk, file_path, current_start, i, 
                        'function', priority
                    ))
                    current_chunk = []
                    current_start = i + 1
                    in_function = False
                    brace_count = 0
        
        # Handle remaining content
        if current_chunk:
            chunks.append(self._create_chunk(
                current_chunk, file_path, current_start, len(lines)-1,
                'general', priority
            ))
        
        return chunks
    
    def _chunk_by_config_blocks(self, lines: List[str], file_path: str, priority: str) -> List[CodeChunk]:
        """Chunk by configuration blocks"""
        chunks = []
        current_chunk = []
        current_start = 0
        indent_level = 0
        block_start_indent = None
        
        for i, line in enumerate(lines):
            line_indent = len(line) - len(line.lstrip())
            
            # Detect new block
            if any(pattern in line for pattern in ['resource ', 'data ', 'variable ', 'apiVersion:', 'kind:', '- name:']):
                if current_chunk:
                    chunks.append(self._create_chunk(
                        current_chunk, file_path, current_start, i-1,
                        'config_block', priority
                    ))
                current_chunk = [line]
                current_start = i
                block_start_indent = line_indent
            else:
                current_chunk.append(line)
                
                # If we're back to the original indent level and have content, end block
                if (block_start_indent is not None and 
                    line_indent <= block_start_indent and 
                    line.strip() and 
                    len(current_chunk) > 10):  # Reasonable block size
                    
                    chunks.append(self._create_chunk(
                        current_chunk[:-1], file_path, current_start, i-1,
                        'config_block', priority
                    ))
                    current_chunk = [line]
                    current_start = i
                    block_start_indent = line_indent
        
        # Handle remaining content
        if current_chunk:
            chunks.append(self._create_chunk(
                current_chunk, file_path, current_start, len(lines)-1,
                'config_block', priority
            ))
        
        return chunks
    
    def _chunk_by_sections(self, lines: List[str], file_path: str, priority: str) -> List[CodeChunk]:
        """Chunk markdown by sections"""
        chunks = []
        current_chunk = []
        current_start = 0
        
        for i, line in enumerate(lines):
            if line.startswith('#') and current_chunk:
                # New section
                chunks.append(self._create_chunk(
                    current_chunk, file_path, current_start, i-1,
                    'documentation', priority
                ))
                current_chunk = [line]
                current_start = i
            else:
                current_chunk.append(line)
        
        # Handle remaining content
        if current_chunk:
            chunks.append(self._create_chunk(
                current_chunk, file_path, current_start, len(lines)-1,
                'documentation', priority
            ))
        
        return chunks
    
    def _chunk_by_sliding_window(self, lines: List[str], file_path: str, priority: str) -> List[CodeChunk]:
        """Fallback sliding window chunking"""
        chunks = []
        chunk_size = self.config.get('chunk_size', 512)
        overlap = self.config.get('chunk_overlap', 50)
        
        current_size = 0
        current_chunk = []
        start_line = 0
        
        for i, line in enumerate(lines):
            current_chunk.append(line)
            current_size += len(line)
            
            if current_size >= chunk_size:
                chunks.append(self._create_chunk(
                    current_chunk, file_path, start_line, i,
                    'general', priority
                ))
                
                # Overlap handling
                overlap_lines = max(1, overlap // (current_size // len(current_chunk)))
                current_chunk = current_chunk[-overlap_lines:]
                start_line = i - len(current_chunk) + 1
                current_size = sum(len(line) for line in current_chunk)
        
        # Handle remaining content
        if current_chunk:
            chunks.append(self._create_chunk(
                current_chunk, file_path, start_line, len(lines)-1,
                'general', priority
            ))
        
        return chunks
    
    def _create_chunk(self, lines: List[str], file_path: str, start_line: int, 
                     end_line: int, chunk_type: str, priority: str) -> CodeChunk:
        """Create a CodeChunk object"""
        content = ''.join(lines).strip()
        
        # Extract metadata
        metadata = {
            'line_count': len(lines),
            'char_count': len(content),
            'has_functions': any('function ' in line or '() {' in line for line in lines),
            'has_comments': any(line.strip().startswith('#') for line in lines),
            'complexity_score': self._calculate_complexity(lines)
        }
        
        return CodeChunk(
            content=content,
            file_path=file_path,
            start_line=start_line,
            end_line=end_line,
            chunk_type=chunk_type,
            priority=priority,
            metadata=metadata
        )
    
    def _calculate_complexity(self, lines: List[str]) -> float:
        """Simple complexity scoring"""
        complexity = 0
        for line in lines:
            # Control structures
            if any(keyword in line for keyword in ['if ', 'for ', 'while ', 'case ', 'function ']):
                complexity += 1
            # Nested structures
            complexity += line.count('{') + line.count('[')
            # Function calls
            complexity += line.count('(') * 0.1
        
        return complexity / len(lines) if lines else 0
    
    def _get_file_priority(self, file_path: str) -> str:
        """Determine file priority based on path and type"""
        path = Path(file_path)
        
        # Check critical files
        critical_patterns = self.config.get('file_type_priorities', {}).get('critical', [])
        for pattern in critical_patterns:
            if path.match(pattern.replace('*', '**')):
                return 'critical'
        
        # Check by extension
        high_exts = ['.sh', '.py', '.tf', '.yaml', '.yml']
        if path.suffix in high_exts:
            return 'high'
        
        medium_exts = ['.json', '.toml', '.ini', '.conf']
        if path.suffix in medium_exts:
            return 'medium'
        
        return 'low'
    
    def _detect_codebase_type(self, file_path: str) -> str:
        """Detect codebase type for context prioritization"""
        path_str = str(file_path).lower()
        
        if 'terraform' in path_str or file_path.endswith('.tf'):
            return 'terraform'
        elif any(k8s in path_str for k8s in ['k8s', 'kubernetes', 'kustomize']):
            return 'kubernetes'
        elif 'ansible' in path_str or file_path.endswith('.yml'):
            return 'ansible'
        elif any(test in path_str for test in ['test', 'validation', 'k3s']):
            return 'k3s-validation'
        
        return 'general'
    
    def index_codebase(self, root_path: str, codebase_name: str = None):
        """Index entire codebase"""
        if not HAS_LOCAL_EMBEDDINGS:
            print("❌ Cannot index without embedding libraries")
            return
        
        root = Path(root_path)
        codebase_name = codebase_name or root.name
        
        print(f"🔄 Indexing codebase: {codebase_name}")
        
        # Get exclusion patterns
        exclusions = self.config.get('exclusion_patterns', [])
        
        # Collect files
        files_to_process = []
        for file_path in root.rglob('*'):
            if file_path.is_file():
                # Check exclusions
                if any(excl in str(file_path) for excl in exclusions):
                    continue
                
                # Check file types
                if file_path.suffix in ['.txt', '.md', '.py', '.sh', '.tf', '.yaml', '.yml', '.json']:
                    files_to_process.append(file_path)
        
        print(f"📁 Found {len(files_to_process)} files to process")
        
        # Process files
        all_chunks = []
        for file_path in files_to_process:
            try:
                chunks = self.chunk_code_file(str(file_path))
                all_chunks.extend(chunks)
                if len(all_chunks) % 100 == 0:
                    print(f"   Processed {len(all_chunks)} chunks...")
            except Exception as e:
                print(f"⚠️  Error processing {file_path}: {e}")
        
        print(f"📦 Generated {len(all_chunks)} chunks")
        
        # Generate embeddings
        print("🔄 Generating embeddings...")
        embeddings = []
        chunk_data = []
        
        for chunk in all_chunks:
            try:
                # Generate embedding
                embedding = self.embedding_model.encode(chunk.content)
                embeddings.append(embedding)
                
                # Store chunk data
                content_hash = hashlib.md5(chunk.content.encode()).hexdigest()
                chunk_data.append((
                    content_hash, chunk.file_path, chunk.start_line, chunk.end_line,
                    chunk.chunk_type, chunk.priority, chunk.content, 
                    json.dumps(chunk.metadata)
                ))
                
            except Exception as e:
                print(f"⚠️  Error processing chunk: {e}")
        
        if embeddings:
            # Add to FAISS index
            embeddings_array = np.array(embeddings).astype('float32')
            faiss.normalize_L2(embeddings_array)  # Normalize for cosine similarity
            
            start_id = self.vector_index.ntotal
            self.vector_index.add(embeddings_array)
            
            # Store in database
            cursor = self.conn.cursor()
            for i, (content_hash, file_path, start_line, end_line, chunk_type, 
                   priority, content, metadata) in enumerate(chunk_data):
                
                embedding_id = start_id + i
                cursor.execute('''
                    INSERT OR REPLACE INTO code_chunks 
                    (content_hash, file_path, start_line, end_line, chunk_type, 
                     priority, content, metadata, embedding_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (content_hash, file_path, start_line, end_line, chunk_type,
                      priority, content, metadata, embedding_id))
            
            # Update codebase metadata
            cursor.execute('''
                INSERT OR REPLACE INTO codebase_metadata 
                (codebase_name, last_indexed, total_chunks, config_hash)
                VALUES (?, ?, ?, ?)
            ''', (codebase_name, datetime.now(), len(chunk_data), 
                  hashlib.md5(json.dumps(self.config).encode()).hexdigest()))
            
            self.conn.commit()
            
            # Save FAISS index
            faiss.write_index(self.vector_index, str(self.index_path))
            
            print(f"✅ Indexed {len(embeddings)} chunks for {codebase_name}")
        else:
            print("❌ No embeddings generated")
    
    def search(self, query: str, max_results: int = None) -> List[Dict[str, Any]]:
        """Search for relevant code chunks"""
        if not HAS_LOCAL_EMBEDDINGS or not self.embedding_model:
            print("❌ Search not available without embeddings")
            return []
        
        max_results = max_results or self.config.get('max_chunks_per_query', 5)
        threshold = self.config.get('similarity_threshold', 0.75)
        
        # Generate query embedding
        query_embedding = self.embedding_model.encode([query])
        query_embedding = query_embedding.astype('float32')
        faiss.normalize_L2(query_embedding)
        
        # Search FAISS index
        scores, indices = self.vector_index.search(query_embedding, max_results * 2)
        
        # Filter by threshold and retrieve metadata
        results = []
        cursor = self.conn.cursor()
        
        for score, idx in zip(scores[0], indices[0]):
            if score >= threshold:
                cursor.execute('''
                    SELECT file_path, start_line, end_line, chunk_type, priority, 
                           content, metadata FROM code_chunks 
                    WHERE embedding_id = ?
                ''', (int(idx),))
                
                row = cursor.fetchone()
                if row:
                    results.append({
                        'similarity_score': float(score),
                        'file_path': row[0],
                        'start_line': row[1],
                        'end_line': row[2],
                        'chunk_type': row[3],
                        'priority': row[4],
                        'content': row[5],
                        'metadata': json.loads(row[6])
                    })
        
        # Sort by priority and similarity
        priority_order = {'critical': 4, 'high': 3, 'medium': 2, 'low': 1}
        results.sort(key=lambda x: (
            priority_order.get(x['priority'], 0),
            x['similarity_score']
        ), reverse=True)
        
        return results[:max_results]
    
    def get_stats(self) -> Dict[str, Any]:
        """Get indexing statistics"""
        cursor = self.conn.cursor()
        
        # Get codebase stats
        cursor.execute('SELECT * FROM codebase_metadata')
        codebases = cursor.fetchall()
        
        # Get chunk stats
        cursor.execute('''
            SELECT priority, COUNT(*), chunk_type, COUNT(*) 
            FROM code_chunks 
            GROUP BY priority, chunk_type
        ''')
        chunk_stats = cursor.fetchall()
        
        total_chunks = self.vector_index.ntotal if self.vector_index else 0
        
        return {
            'total_chunks': total_chunks,
            'codebases': len(codebases),
            'codebase_details': codebases,
            'chunk_distribution': chunk_stats,
            'index_size_mb': self.index_path.stat().st_size / 1024 / 1024 if self.index_path.exists() else 0,
            'db_size_mb': self.db_path.stat().st_size / 1024 / 1024 if self.db_path.exists() else 0
        }

def main():
    parser = argparse.ArgumentParser(description='Local RAG System for Claude Code')
    parser.add_argument('command', choices=['index', 'search', 'stats'], help='Command to run')
    parser.add_argument('--path', help='Path to index (for index command)')
    parser.add_argument('--name', help='Codebase name (for index command)')
    parser.add_argument('--query', help='Search query (for search command)')
    parser.add_argument('--max-results', type=int, default=5, help='Maximum search results')
    parser.add_argument('--config', help='Path to config file')
    
    args = parser.parse_args()
    
    # Initialize RAG system
    rag = LocalRAGSystem(args.config)
    
    if args.command == 'index':
        if not args.path:
            print("❌ --path required for index command")
            return
        rag.index_codebase(args.path, args.name)
    
    elif args.command == 'search':
        if not args.query:
            print("❌ --query required for search command")
            return
        
        results = rag.search(args.query, args.max_results)
        
        print(f"🔍 Search results for: {args.query}")
        print("=" * 50)
        
        for i, result in enumerate(results, 1):
            print(f"\n{i}. {result['file_path']}:{result['start_line']}-{result['end_line']}")
            print(f"   Priority: {result['priority']}, Type: {result['chunk_type']}")
            print(f"   Similarity: {result['similarity_score']:.3f}")
            print(f"   Content preview: {result['content'][:200]}...")
    
    elif args.command == 'stats':
        stats = rag.get_stats()
        print("📊 RAG System Statistics")
        print("=" * 30)
        print(f"Total chunks: {stats['total_chunks']}")
        print(f"Codebases: {stats['codebases']}")
        print(f"Index size: {stats['index_size_mb']:.2f} MB")
        print(f"Database size: {stats['db_size_mb']:.2f} MB")
        
        if stats['chunk_distribution']:
            print("\nChunk distribution:")
            for priority, count, chunk_type, type_count in stats['chunk_distribution']:
                print(f"  {priority}: {count} chunks")

if __name__ == '__main__':
    main()