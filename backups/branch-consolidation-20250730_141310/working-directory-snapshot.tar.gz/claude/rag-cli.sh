#!/bin/bash
# Claude Code RAG CLI Integration
# Provides optimized context for claude CLI using local embeddings

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RAG_SETUP="$SCRIPT_DIR/local-rag-setup.py"
CONFIG_FILE="$SCRIPT_DIR/rag-config.json"

# Colors for output
readonly GREEN='\033[0;32m'
readonly BLUE='\033[0;34m'
readonly YELLOW='\033[1;33m'
readonly RED='\033[0;31m'
readonly NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_dependencies() {
    log_info "Checking dependencies..."
    
    # Check Python
    if ! command -v python3 >/dev/null 2>&1; then
        log_error "Python 3 is required but not installed"
        exit 1
    fi
    
    # Check required Python packages
    local missing_packages=()
    
    if ! python3 -c "import sentence_transformers" 2>/dev/null; then
        missing_packages+=("sentence-transformers")
    fi
    
    if ! python3 -c "import faiss" 2>/dev/null; then
        missing_packages+=("faiss-cpu")
    fi
    
    if ! python3 -c "import numpy" 2>/dev/null; then
        missing_packages+=("numpy")
    fi
    
    if [[ ${#missing_packages[@]} -gt 0 ]]; then
        log_warning "Missing Python packages: ${missing_packages[*]}"
        log_info "Install with: pip install ${missing_packages[*]}"
        
        read -p "Install missing packages now? (y/N): " -r
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            pip install "${missing_packages[@]}"
            log_success "Packages installed successfully"
        else
            log_error "Required packages not installed. Exiting."
            exit 1
        fi
    else
        log_success "All dependencies satisfied"
    fi
}

setup_initial_config() {
    if [[ ! -f "$CONFIG_FILE" ]]; then
        log_info "Creating initial RAG configuration..."
        
        # The config file was already created by the previous step
        if [[ -f "$SCRIPT_DIR/rag-config.json" ]]; then
            log_success "RAG configuration already exists"
        else
            log_error "RAG configuration not found. Please ensure rag-config.json exists."
            exit 1
        fi
    fi
}

index_codebase() {
    local codebase_path="${1:-$(pwd)}"
    local codebase_name="${2:-$(basename "$codebase_path")}"
    
    log_info "Indexing codebase: $codebase_name at $codebase_path"
    
    if [[ ! -d "$codebase_path" ]]; then
        log_error "Directory not found: $codebase_path"
        exit 1
    fi
    
    python3 "$RAG_SETUP" index --path "$codebase_path" --name "$codebase_name" --config "$CONFIG_FILE"
    
    if [[ $? -eq 0 ]]; then
        log_success "Indexing completed for $codebase_name"
    else
        log_error "Indexing failed for $codebase_name"
        exit 1
    fi
}

search_context() {
    local query="$1"
    local max_results="${2:-5}"
    
    log_info "Searching for context: $query"
    
    python3 "$RAG_SETUP" search --query "$query" --max-results "$max_results" --config "$CONFIG_FILE"
}

generate_claude_context() {
    local query="$1"
    local output_file="${2:-/tmp/claude-context.md}"
    local max_results="${3:-5}"
    
    log_info "Generating optimized Claude context for: $query"
    
    # Get search results in structured format
    local search_results
    search_results=$(python3 "$RAG_SETUP" search --query "$query" --max-results "$max_results" --config "$CONFIG_FILE" 2>/dev/null)
    
    # Generate context file
    cat > "$output_file" <<EOF
# Claude Code Context - Generated $(date)

## Query: $query

## Relevant Code Context

$search_results

## Usage Instructions
This context has been optimized for token efficiency while maintaining relevance to your query.
Priority levels indicate importance: critical > high > medium > low

EOF
    
    log_success "Context generated: $output_file"
    echo "$output_file"
}

show_stats() {
    log_info "RAG System Statistics"
    python3 "$RAG_SETUP" stats --config "$CONFIG_FILE"
}

claude_integrate() {
    local query="$1"
    local claude_args="${2:-}"
    
    log_info "Integrating with Claude CLI..."
    
    # Generate context
    local context_file
    context_file=$(generate_claude_context "$query" "/tmp/claude-rag-context-$(date +%s).md")
    
    # Build claude command
    local claude_cmd="claude"
    
    if [[ -n "$claude_args" ]]; then
        claude_cmd="$claude_cmd $claude_args"
    fi
    
    # Add context to the conversation
    echo "🤖 Executing: $claude_cmd with RAG context"
    echo "📄 Context file: $context_file"
    echo ""
    
    # Option 1: Include context in the prompt
    echo "# RAG-Enhanced Claude Session"
    echo "Context has been loaded for query: $query"
    echo ""
    echo "You can now interact with Claude using this optimized context."
    echo "Context file: $context_file"
    
    # Option 2: Direct integration (if supported)
    # $claude_cmd --context-file "$context_file"
}

auto_index_project() {
    local project_root="${1:-$(pwd)}"
    
    log_info "Auto-indexing project structure..."
    
    # Detect project types and index accordingly
    local project_types=()
    
    if [[ -f "$project_root/orchestrator.sh" ]] || [[ -d "$project_root/modules" ]]; then
        project_types+=("k3s-testing-framework")
    fi
    
    if [[ -f "$project_root/main.tf" ]] || [[ -f "$project_root/terraform.tf" ]]; then
        project_types+=("terraform")
    fi
    
    if [[ -f "$project_root/playbook.yml" ]] || [[ -d "$project_root/roles" ]]; then
        project_types+=("ansible")
    fi
    
    if [[ -f "$project_root/kustomization.yaml" ]] || find "$project_root" -name "*.yaml" -o -name "*.yml" | grep -q kubernetes; then
        project_types+=("kubernetes")
    fi
    
    if [[ ${#project_types[@]} -eq 0 ]]; then
        project_types+=("general")
    fi
    
    log_info "Detected project types: ${project_types[*]}"
    
    # Index the project
    index_codebase "$project_root" "$(basename "$project_root")"
}

usage() {
    cat <<EOF
Claude Code RAG CLI - Local Embedding-Based Context Optimization

USAGE:
    $0 COMMAND [OPTIONS]

COMMANDS:
    setup                           Setup dependencies and initial configuration
    index <path> [name]            Index a codebase for RAG
    auto-index [path]              Auto-detect and index project
    search <query> [max-results]   Search for relevant code context
    context <query> [output-file]  Generate Claude-optimized context file
    claude <query> [claude-args]   Integrate with Claude CLI
    stats                          Show RAG system statistics
    help                           Show this help message

EXAMPLES:
    # Initial setup
    $0 setup

    # Index the current project
    $0 auto-index

    # Index a specific codebase
    $0 index /path/to/k3s-validation k3s-framework

    # Search for relevant context
    $0 search "error handling in shell scripts"

    # Generate context for Claude
    $0 context "kubernetes deployment issues" /tmp/k8s-context.md

    # Integrate with Claude CLI
    $0 claude "help debug the orchestrator script"

    # View system statistics
    $0 stats

CONFIGURATION:
    Configuration file: $CONFIG_FILE
    Edit this file to customize:
    - Embedding model selection
    - Chunk sizes and overlap
    - File type priorities
    - Exclusion patterns

DEPENDENCIES:
    - Python 3.7+
    - sentence-transformers
    - faiss-cpu
    - numpy

The system uses local compute for embeddings to minimize external API costs
while providing optimized context for Claude Code interactions.

EOF
}

main() {
    case "${1:-help}" in
        setup)
            check_dependencies
            setup_initial_config
            log_success "RAG system setup complete"
            ;;
        index)
            if [[ $# -lt 2 ]]; then
                log_error "Usage: $0 index <path> [name]"
                exit 1
            fi
            check_dependencies
            index_codebase "${2}" "${3:-}"
            ;;
        auto-index)
            check_dependencies
            auto_index_project "${2:-$(pwd)}"
            ;;
        search)
            if [[ $# -lt 2 ]]; then
                log_error "Usage: $0 search <query> [max-results]"
                exit 1
            fi
            search_context "${2}" "${3:-5}"
            ;;
        context)
            if [[ $# -lt 2 ]]; then
                log_error "Usage: $0 context <query> [output-file]"
                exit 1
            fi
            generate_claude_context "${2}" "${3:-/tmp/claude-context.md}"
            ;;
        claude)
            if [[ $# -lt 2 ]]; then
                log_error "Usage: $0 claude <query> [claude-args]"
                exit 1
            fi
            claude_integrate "${2}" "${3:-}"
            ;;
        stats)
            show_stats
            ;;
        help|--help|-h)
            usage
            ;;
        *)
            log_error "Unknown command: $1"
            usage
            exit 1
            ;;
    esac
}

main "$@"