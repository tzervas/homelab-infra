#!/usr/bin/env python3
"""
RAG System Integration with Observability
Complete integration of local RAG with GPU safety and full observability
"""

import os
import json
import time
import argparse
from pathlib import Path
from typing import Dict, List, Any, Optional
from contextlib import contextmanager

# Import our RAG components
try:
    from local_rag_setup import LocalRAGSystem, GPUMonitor
    from rag_observability import RAGObservabilitySystem, get_observability, track_embedding_operation
    HAS_RAG_COMPONENTS = True
except ImportError as e:
    print(f"⚠️  RAG components not available: {e}")
    HAS_RAG_COMPONENTS = False

class IntegratedRAGSystem:
    """Complete RAG system with observability and GPU safety"""
    
    def __init__(self, config_path: str = ".claude/rag-config.json"):
        self.config_path = config_path
        
        # Initialize core components
        self.rag_system = None
        self.observability = None
        self.gpu_monitor = None
        
        if HAS_RAG_COMPONENTS:
            self._init_components()
        else:
            print("❌ Cannot initialize without RAG components")
    
    def _init_components(self):
        """Initialize all system components"""
        print("🔄 Initializing integrated RAG system...")
        
        # Initialize observability first
        self.observability = get_observability()
        self.observability.start_monitoring()
        
        # Initialize RAG system with observability hooks
        self.rag_system = LocalRAGSystem(self.config_path)
        
        # Get GPU monitor from RAG system
        self.gpu_monitor = self.rag_system.gpu_monitor
        
        print("✅ Integrated RAG system initialized")
    
    def index_codebase_with_observability(self, root_path: str, codebase_name: str = None):
        """Index codebase with full observability tracking"""
        if not self.rag_system:
            print("❌ RAG system not available")
            return
        
        codebase_name = codebase_name or Path(root_path).name
        
        with track_embedding_operation('batch_index', 'all-MiniLM-L6-v2', f"Indexing {codebase_name}") as op:
            # Update operation metadata
            op.metadata = {'codebase': codebase_name, 'path': root_path}
            
            # Perform indexing
            self.rag_system.index_codebase(root_path, codebase_name)
            
            # Update chunk count in operation
            stats = self.rag_system.get_stats()
            op.chunk_count = stats.get('total_chunks', 0)
    
    def search_with_observability(self, query: str, max_results: int = 5) -> List[Dict[str, Any]]:
        """Search with full performance tracking"""
        if not self.rag_system:
            print("❌ RAG system not available")
            return []
        
        start_time = time.time()
        
        with track_embedding_operation('search', 'all-MiniLM-L6-v2', query) as op:
            results = self.rag_system.search(query, max_results)
            
            # Track search performance
            search_time = time.time() - start_time
            self.observability.track_search_operation(
                query=query,
                similarity_threshold=self.rag_system.config.get('similarity_threshold', 0.75),
                max_results=max_results,
                results_count=len(results),
                search_time=search_time
            )
            
            # Update operation metadata
            op.chunk_count = len(results)
            op.metadata = {'query_length': len(query), 'results_found': len(results)}
            
            return results
    
    def generate_optimized_context(self, query: str, output_file: str = None) -> str:
        """Generate Claude-optimized context with observability"""
        results = self.search_with_observability(query)
        
        if not results:
            return "No relevant context found for the query."
        
        # Build optimized context
        context_parts = [
            f"# Context for: {query}\n",
            f"*Generated at {time.strftime('%Y-%m-%d %H:%M:%S')}*\n",
            f"*Found {len(results)} relevant code sections*\n\n"
        ]
        
        for i, result in enumerate(results, 1):
            context_parts.extend([
                f"## {i}. {Path(result['file_path']).name}:{result['start_line']}-{result['end_line']}\n",
                f"**Priority**: {result['priority']} | **Type**: {result['chunk_type']} | **Similarity**: {result['similarity_score']:.3f}\n\n",
                "```\n",
                result['content'],
                "\n```\n\n"
            ])
        
        context = ''.join(context_parts)
        
        # Save to file if specified
        if output_file:
            with open(output_file, 'w') as f:
                f.write(context)
            print(f"📄 Context saved to: {output_file}")
        
        return context
    
    def get_comprehensive_stats(self) -> Dict[str, Any]:
        """Get comprehensive system statistics"""
        stats = {}
        
        if self.rag_system:
            stats['rag'] = self.rag_system.get_stats()
        
        if self.observability:
            stats['performance'] = self.observability.generate_performance_report(hours=24)
            stats['real_time'] = self.observability.get_real_time_dashboard_data()
        
        if self.gpu_monitor:
            stats['gpu'] = self.gpu_monitor.get_gpu_stats()
        
        return stats
    
    def start_prometheus_server(self, port: int = 8000):
        """Start Prometheus metrics server"""
        if self.observability:
            self.observability.start_prometheus_server(port)
        else:
            print("❌ Observability not available")
    
    def export_metrics(self, format: str = 'json') -> str:
        """Export system metrics"""
        if self.observability:
            return self.observability.export_metrics(format)
        else:
            print("❌ Observability not available")
            return ""
    
    def health_check(self) -> Dict[str, bool]:
        """Comprehensive system health check"""
        health = {
            'rag_system': self.rag_system is not None,
            'observability': self.observability is not None,
            'gpu_monitor': self.gpu_monitor is not None,
            'gpu_safety': False,
            'embeddings_available': False,
            'vector_index': False
        }
        
        if self.gpu_monitor:
            health['gpu_safety'] = self.gpu_monitor.check_gpu_safety()
        
        if self.rag_system:
            health['embeddings_available'] = self.rag_system.embedding_model is not None
            health['vector_index'] = self.rag_system.vector_index is not None
        
        return health
    
    def shutdown(self):
        """Clean shutdown of all components"""
        print("🔄 Shutting down integrated RAG system...")
        
        if self.observability:
            self.observability.stop_monitoring()
        
        if self.gpu_monitor:
            self.gpu_monitor.stop_monitoring()
        
        print("✅ System shutdown complete")
    
    @contextmanager
    def session(self):
        """Context manager for RAG session"""
        try:
            yield self
        finally:
            self.shutdown()

def demo_integrated_system():
    """Demonstrate the complete integrated system"""
    print("🚀 Integrated RAG System Demo")
    print("=" * 40)
    
    with IntegratedRAGSystem().session() as rag:
        # Health check
        print("\n📊 System Health Check:")
        health = rag.health_check()
        for component, status in health.items():
            status_icon = "✅" if status else "❌"
            print(f"   {status_icon} {component}")
        
        if not all(health.values()):
            print("\n⚠️  System not fully operational - some features may be limited")
        
        # Show current stats
        print("\n📈 Current System Statistics:")
        stats = rag.get_comprehensive_stats()
        
        if 'rag' in stats:
            rag_stats = stats['rag']
            print(f"   📚 Total chunks: {rag_stats.get('total_chunks', 0)}")
            print(f"   📁 Indexed codebases: {rag_stats.get('codebases', 0)}")
            print(f"   💾 Index size: {rag_stats.get('index_size_mb', 0):.1f} MB")
        
        if 'gpu' in stats:
            gpu_stats = stats['gpu']
            if gpu_stats.get('gpu_available'):
                print(f"   🖥️  GPU available: {gpu_stats.get('gpu_count', 0)} device(s)")
                for gpu in gpu_stats.get('gpus', []):
                    print(f"      GPU {gpu['id']}: {gpu['name']} ({gpu['temperature']}°C)")
        
        # Demo search with observability
        print("\n🔍 Demo Search Query:")
        query = "orchestrator script error handling"
        print(f"   Query: '{query}'")
        
        results = rag.search_with_observability(query, max_results=3)
        print(f"   Results found: {len(results)}")
        
        for i, result in enumerate(results[:2], 1):  # Show first 2 results
            print(f"   {i}. {Path(result['file_path']).name}:{result['start_line']} (score: {result['similarity_score']:.3f})")
        
        # Generate context
        print("\n📄 Generating Context:")
        context = rag.generate_optimized_context(query)
        print(f"   Context length: {len(context)} characters")
        print(f"   Preview: {context[:200]}...")
        
        # Show recent performance
        if 'performance' in stats:
            perf = stats['performance']
            print(f"\n⏱️  Performance Metrics (24h):")
            if perf.get('operation_statistics'):
                total_ops = sum(op['count'] for op in perf['operation_statistics'])
                avg_time = sum(op['avg_time'] * op['count'] for op in perf['operation_statistics']) / max(total_ops, 1)
                print(f"   Total operations: {total_ops}")
                print(f"   Average time: {avg_time:.3f}s")

def main():
    parser = argparse.ArgumentParser(description='Integrated RAG System with Observability')
    parser.add_argument('command', 
                       choices=['demo', 'health', 'stats', 'index', 'search', 'context', 'prometheus'], 
                       help='Command to run')
    parser.add_argument('--path', help='Path to index')
    parser.add_argument('--name', help='Codebase name')
    parser.add_argument('--query', help='Search query')
    parser.add_argument('--output', help='Output file for context')
    parser.add_argument('--port', type=int, default=8000, help='Prometheus server port')
    parser.add_argument('--max-results', type=int, default=5, help='Maximum search results')
    
    args = parser.parse_args()
    
    if args.command == 'demo':
        demo_integrated_system()
        return
    
    # Initialize system for other commands
    rag = IntegratedRAGSystem()
    
    try:
        if args.command == 'health':
            health = rag.health_check()
            print("🏥 System Health:")
            for component, status in health.items():
                status_icon = "✅" if status else "❌"
                print(f"   {status_icon} {component}")
        
        elif args.command == 'stats':
            stats = rag.get_comprehensive_stats()
            print("📊 Comprehensive Statistics:")
            print(json.dumps(stats, indent=2, default=str))
        
        elif args.command == 'index':
            if not args.path:
                print("❌ --path required for index command")
                return
            rag.index_codebase_with_observability(args.path, args.name)
        
        elif args.command == 'search':
            if not args.query:
                print("❌ --query required for search command")
                return
            results = rag.search_with_observability(args.query, args.max_results)
            print(f"🔍 Found {len(results)} results for: {args.query}")
            for i, result in enumerate(results, 1):
                print(f"{i}. {result['file_path']}:{result['start_line']} (score: {result['similarity_score']:.3f})")
        
        elif args.command == 'context':
            if not args.query:
                print("❌ --query required for context command")
                return
            context = rag.generate_optimized_context(args.query, args.output)
            if not args.output:
                print("📄 Generated Context:")
                print(context[:500] + "..." if len(context) > 500 else context)
        
        elif args.command == 'prometheus':
            rag.start_prometheus_server(args.port)
            print("📊 Prometheus server running. Press Ctrl+C to stop.")
            try:
                while True:
                    time.sleep(60)
            except KeyboardInterrupt:
                pass
    
    finally:
        rag.shutdown()

if __name__ == '__main__':
    main()