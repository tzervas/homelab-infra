#!/usr/bin/env python3
"""
RAG Observability and Transcoding System
Provides comprehensive monitoring, logging, and transparency for the RAG system
"""

import os
import json
import time
import sqlite3
import hashlib
import threading
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from contextlib import contextmanager
import logging

# Performance and monitoring libraries
try:
    import prometheus_client
    from prometheus_client import Counter, Histogram, Gauge, Summary, CollectorRegistry
    import psutil
    import GPUtil
    import matplotlib.pyplot as plt
    import seaborn as sns
    import numpy as np
    import pandas as pd
    HAS_MONITORING = True
except ImportError as e:
    print(f"⚠️  Install monitoring dependencies: pip install prometheus-client psutil GPUtil matplotlib seaborn pandas")
    HAS_MONITORING = False

@dataclass
class EmbeddingOperation:
    """Represents a single embedding operation for tracking"""
    operation_id: str
    timestamp: datetime
    operation_type: str  # 'index', 'search', 'batch'
    input_text: str
    input_size: int
    chunk_count: int
    processing_time: float
    gpu_used: bool
    gpu_memory_before: Optional[float]
    gpu_memory_after: Optional[float]
    gpu_temperature: Optional[float]
    cpu_usage: float
    memory_usage: float
    model_name: str
    batch_size: int
    success: bool
    error_message: Optional[str] = None

@dataclass
class SystemMetrics:
    """System performance metrics snapshot"""
    timestamp: datetime
    cpu_percent: float
    memory_percent: float
    memory_available_gb: float
    gpu_stats: List[Dict[str, Any]]
    disk_usage_percent: float
    temperature: Optional[float]
    power_usage: Optional[float]

class RAGObservabilitySystem:
    """Comprehensive observability and monitoring for RAG operations"""
    
    def __init__(self, config_path: str = ".claude/observability-config.json"):
        self.config_path = config_path
        self.config = self._load_config()
        
        # Database for storing metrics
        self.db_path = Path(".claude/observability.db")
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Prometheus metrics
        self.registry = CollectorRegistry()
        self._init_prometheus_metrics()
        
        # Logging setup
        self._setup_logging()
        
        # Initialize database
        self._init_database()
        
        # Background monitoring
        self.monitoring_active = False
        self.monitoring_thread = None
        
        # Performance tracking
        self.current_operations = {}  # Track ongoing operations
        self.operation_history = []   # Recent operations for analysis
        
        print("📊 RAG Observability System initialized")
    
    def _load_config(self) -> Dict[str, Any]:
        """Load observability configuration"""
        default_config = {
            "metrics_retention_days": 30,
            "detailed_logging": True,
            "prometheus_port": 8000,
            "monitoring_interval": 5,
            "gpu_monitoring": True,
            "performance_alerts": {
                "max_embedding_time": 30.0,
                "max_gpu_temperature": 80.0,
                "max_memory_usage": 0.85
            },
            "transcoding": {
                "enabled": True,
                "format": "json",
                "include_embeddings": False,
                "compression": "gzip"
            }
        }
        
        try:
            with open(self.config_path, 'r') as f:
                user_config = json.load(f)
                default_config.update(user_config)
        except FileNotFoundError:
            # Save default config
            with open(self.config_path, 'w') as f:
                json.dump(default_config, f, indent=2)
        
        return default_config
    
    def _init_prometheus_metrics(self):
        """Initialize Prometheus metrics collectors"""
        if not HAS_MONITORING:
            return
        
        # Embedding operation metrics
        self.embedding_operations_total = Counter(
            'rag_embedding_operations_total',
            'Total number of embedding operations',
            ['operation_type', 'model_name', 'success'],
            registry=self.registry
        )
        
        self.embedding_duration = Histogram(
            'rag_embedding_duration_seconds',
            'Time spent on embedding operations',
            ['operation_type', 'model_name'],
            registry=self.registry
        )
        
        self.embedding_batch_size = Histogram(
            'rag_embedding_batch_size',
            'Batch sizes used for embedding operations',
            ['operation_type'],
            registry=self.registry
        )
        
        # System resource metrics
        self.gpu_temperature = Gauge(
            'rag_gpu_temperature_celsius',
            'GPU temperature',
            ['gpu_id', 'gpu_name'],
            registry=self.registry
        )
        
        self.gpu_memory_usage = Gauge(
            'rag_gpu_memory_usage_percent',
            'GPU memory usage percentage',
            ['gpu_id', 'gpu_name'],
            registry=self.registry
        )
        
        self.cpu_usage = Gauge(
            'rag_cpu_usage_percent',
            'CPU usage percentage',
            registry=self.registry
        )
        
        self.memory_usage = Gauge(
            'rag_memory_usage_percent',
            'System memory usage percentage',
            registry=self.registry
        )
        
        # Vector database metrics
        self.vector_index_size = Gauge(
            'rag_vector_index_size_bytes',
            'Size of vector index in bytes',
            registry=self.registry
        )
        
        self.total_embeddings = Gauge(
            'rag_total_embeddings_count',
            'Total number of embeddings stored',
            registry=self.registry
        )
        
        # Search performance metrics
        self.search_latency = Histogram(
            'rag_search_latency_seconds',
            'Time spent on similarity searches',
            ['similarity_threshold'],
            registry=self.registry
        )
        
        self.search_results_count = Histogram(
            'rag_search_results_count',
            'Number of results returned by searches',
            registry=self.registry
        )
    
    def _setup_logging(self):
        """Setup structured logging"""
        log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        
        # Create logs directory
        log_dir = Path(".claude/logs")
        log_dir.mkdir(parents=True, exist_ok=True)
        
        # Configure root logger
        logging.basicConfig(
            level=logging.INFO if self.config['detailed_logging'] else logging.WARNING,
            format=log_format
        )
        
        # Create specific loggers
        self.logger = logging.getLogger('RAGObservability')
        
        # File handler for persistent logging
        file_handler = logging.FileHandler(log_dir / 'rag-observability.log')
        file_handler.setFormatter(logging.Formatter(log_format))
        self.logger.addHandler(file_handler)
        
        # Performance logger for metrics
        self.perf_logger = logging.getLogger('RAGPerformance')
        perf_handler = logging.FileHandler(log_dir / 'rag-performance.log')
        perf_handler.setFormatter(logging.Formatter(log_format))
        self.perf_logger.addHandler(perf_handler)
    
    def _init_database(self):
        """Initialize SQLite database for metrics storage"""
        self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        
        # Operations table
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS embedding_operations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                operation_id TEXT UNIQUE,
                timestamp DATETIME,
                operation_type TEXT,
                input_size INTEGER,
                chunk_count INTEGER,
                processing_time REAL,
                gpu_used BOOLEAN,
                gpu_memory_before REAL,
                gpu_memory_after REAL,
                gpu_temperature REAL,
                cpu_usage REAL,
                memory_usage REAL,
                model_name TEXT,
                batch_size INTEGER,
                success BOOLEAN,
                error_message TEXT
            )
        ''')
        
        # System metrics table
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS system_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME,
                cpu_percent REAL,
                memory_percent REAL,
                memory_available_gb REAL,
                gpu_stats TEXT,
                disk_usage_percent REAL,
                temperature REAL,
                power_usage REAL
            )
        ''')
        
        # Search performance table
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS search_operations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME,
                query_text TEXT,
                query_hash TEXT,
                similarity_threshold REAL,
                max_results INTEGER,
                results_count INTEGER,
                search_time REAL,
                vector_ops_count INTEGER,
                cache_hit BOOLEAN
            )
        ''')
        
        self.conn.commit()
    
    @contextmanager
    def track_operation(self, operation_type: str, model_name: str, input_text: str = "", batch_size: int = 1):
        """Context manager to track embedding operations"""
        operation_id = hashlib.md5(f"{time.time()}{operation_type}".encode()).hexdigest()[:8]
        start_time = time.time()
        
        # Capture initial system state
        initial_metrics = self._capture_system_metrics()
        
        operation = EmbeddingOperation(
            operation_id=operation_id,
            timestamp=datetime.now(),
            operation_type=operation_type,
            input_text=input_text[:100] + "..." if len(input_text) > 100 else input_text,
            input_size=len(input_text),
            chunk_count=0,
            processing_time=0.0,
            gpu_used=False,
            gpu_memory_before=initial_metrics.gpu_stats[0]['memory_util'] if initial_metrics.gpu_stats else None,
            gpu_memory_after=None,
            gpu_temperature=initial_metrics.gpu_stats[0]['temperature'] if initial_metrics.gpu_stats else None,
            cpu_usage=initial_metrics.cpu_percent,
            memory_usage=initial_metrics.memory_percent,
            model_name=model_name,
            batch_size=batch_size,
            success=False
        )
        
        self.current_operations[operation_id] = operation
        
        try:
            self.logger.info(f"Started operation {operation_id}: {operation_type}")
            yield operation
            
            # Operation completed successfully
            end_time = time.time()
            operation.processing_time = end_time - start_time
            operation.success = True
            
            # Capture final system state
            final_metrics = self._capture_system_metrics()
            if final_metrics.gpu_stats:
                operation.gpu_memory_after = final_metrics.gpu_stats[0]['memory_util']
                operation.gpu_used = True
            
            self.logger.info(f"Completed operation {operation_id} in {operation.processing_time:.3f}s")
            
        except Exception as e:
            # Operation failed
            end_time = time.time()
            operation.processing_time = end_time - start_time
            operation.success = False
            operation.error_message = str(e)
            
            self.logger.error(f"Operation {operation_id} failed: {e}")
            raise
            
        finally:
            # Record the operation
            self._record_operation(operation)
            self._update_prometheus_metrics(operation)
            
            # Remove from current operations
            self.current_operations.pop(operation_id, None)
            
            # Add to history (keep last 100 operations)
            self.operation_history.append(operation)
            if len(self.operation_history) > 100:
                self.operation_history.pop(0)
    
    def _capture_system_metrics(self) -> SystemMetrics:
        """Capture current system performance metrics"""
        gpu_stats = []
        if HAS_MONITORING:
            try:
                gpus = GPUtil.getGPUs()
                for gpu in gpus:
                    gpu_stats.append({
                        'id': gpu.id,
                        'name': gpu.name,
                        'memory_util': gpu.memoryUtil,
                        'temperature': gpu.temperature,
                        'load': gpu.load
                    })
            except:
                pass
        
        return SystemMetrics(
            timestamp=datetime.now(),
            cpu_percent=psutil.cpu_percent(),
            memory_percent=psutil.virtual_memory().percent,
            memory_available_gb=psutil.virtual_memory().available / (1024**3),
            gpu_stats=gpu_stats,
            disk_usage_percent=psutil.disk_usage('/').percent,
            temperature=None,  # Would need specific hardware monitoring
            power_usage=None   # Would need power monitoring hardware
        )
    
    def _record_operation(self, operation: EmbeddingOperation):
        """Record operation in database"""
        cursor = self.conn.cursor()
        cursor.execute('''
            INSERT INTO embedding_operations 
            (operation_id, timestamp, operation_type, input_size, chunk_count,
             processing_time, gpu_used, gpu_memory_before, gpu_memory_after,
             gpu_temperature, cpu_usage, memory_usage, model_name, batch_size,
             success, error_message)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            operation.operation_id, operation.timestamp, operation.operation_type,
            operation.input_size, operation.chunk_count, operation.processing_time,
            operation.gpu_used, operation.gpu_memory_before, operation.gpu_memory_after,
            operation.gpu_temperature, operation.cpu_usage, operation.memory_usage,
            operation.model_name, operation.batch_size, operation.success,
            operation.error_message
        ))
        self.conn.commit()
    
    def _update_prometheus_metrics(self, operation: EmbeddingOperation):
        """Update Prometheus metrics"""
        if not HAS_MONITORING:
            return
        
        # Update counters and histograms
        self.embedding_operations_total.labels(
            operation_type=operation.operation_type,
            model_name=operation.model_name,
            success=str(operation.success)
        ).inc()
        
        self.embedding_duration.labels(
            operation_type=operation.operation_type,
            model_name=operation.model_name
        ).observe(operation.processing_time)
        
        self.embedding_batch_size.labels(
            operation_type=operation.operation_type
        ).observe(operation.batch_size)
    
    def start_monitoring(self):
        """Start background system monitoring"""
        if self.monitoring_active:
            return
        
        self.monitoring_active = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()
        
        self.logger.info("Started background system monitoring")
        print("📊 Background monitoring started")
    
    def stop_monitoring(self):
        """Stop background monitoring"""
        self.monitoring_active = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=10)
        
        self.logger.info("Stopped background system monitoring")
        print("📊 Background monitoring stopped")
    
    def _monitoring_loop(self):
        """Background monitoring loop"""
        interval = self.config.get('monitoring_interval', 5)
        
        while self.monitoring_active:
            try:
                metrics = self._capture_system_metrics()
                self._record_system_metrics(metrics)
                self._update_system_prometheus_metrics(metrics)
                
                # Check for performance alerts
                self._check_performance_alerts(metrics)
                
                time.sleep(interval)
                
            except Exception as e:
                self.logger.error(f"Monitoring loop error: {e}")
                time.sleep(interval * 2)  # Back off on errors
    
    def _record_system_metrics(self, metrics: SystemMetrics):
        """Record system metrics in database"""
        cursor = self.conn.cursor()
        cursor.execute('''
            INSERT INTO system_metrics 
            (timestamp, cpu_percent, memory_percent, memory_available_gb,
             gpu_stats, disk_usage_percent, temperature, power_usage)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            metrics.timestamp, metrics.cpu_percent, metrics.memory_percent,
            metrics.memory_available_gb, json.dumps(metrics.gpu_stats),
            metrics.disk_usage_percent, metrics.temperature, metrics.power_usage
        ))
        self.conn.commit()
    
    def _update_system_prometheus_metrics(self, metrics: SystemMetrics):
        """Update system Prometheus metrics"""
        if not HAS_MONITORING:
            return
        
        self.cpu_usage.set(metrics.cpu_percent)
        self.memory_usage.set(metrics.memory_percent)
        
        for gpu_stat in metrics.gpu_stats:
            self.gpu_temperature.labels(
                gpu_id=str(gpu_stat['id']),
                gpu_name=gpu_stat['name']
            ).set(gpu_stat['temperature'])
            
            self.gpu_memory_usage.labels(
                gpu_id=str(gpu_stat['id']),
                gpu_name=gpu_stat['name']
            ).set(gpu_stat['memory_util'] * 100)
    
    def _check_performance_alerts(self, metrics: SystemMetrics):
        """Check for performance alerts and log warnings"""
        alerts = self.config.get('performance_alerts', {})
        
        # Check GPU temperature
        max_gpu_temp = alerts.get('max_gpu_temperature', 80.0)
        for gpu_stat in metrics.gpu_stats:
            if gpu_stat['temperature'] > max_gpu_temp:
                self.logger.warning(f"GPU {gpu_stat['id']} temperature high: {gpu_stat['temperature']}°C")
        
        # Check memory usage
        max_memory = alerts.get('max_memory_usage', 0.85)
        if metrics.memory_percent / 100 > max_memory:
            self.logger.warning(f"System memory usage high: {metrics.memory_percent:.1f}%")
    
    def track_search_operation(self, query: str, similarity_threshold: float, 
                             max_results: int, results_count: int, search_time: float):
        """Track search operation performance"""
        query_hash = hashlib.md5(query.encode()).hexdigest()[:8]
        
        cursor = self.conn.cursor()
        cursor.execute('''
            INSERT INTO search_operations 
            (timestamp, query_text, query_hash, similarity_threshold, max_results,
             results_count, search_time, vector_ops_count, cache_hit)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            datetime.now(), query[:200], query_hash, similarity_threshold,
            max_results, results_count, search_time, 0, False
        ))
        self.conn.commit()
        
        # Update Prometheus metrics
        if HAS_MONITORING:
            self.search_latency.labels(
                similarity_threshold=str(similarity_threshold)
            ).observe(search_time)
            
            self.search_results_count.observe(results_count)
    
    def generate_performance_report(self, hours: int = 24) -> Dict[str, Any]:
        """Generate comprehensive performance report"""
        since = datetime.now() - timedelta(hours=hours)
        
        cursor = self.conn.cursor()
        
        # Operation statistics
        cursor.execute('''
            SELECT operation_type, COUNT(*), AVG(processing_time), 
                   AVG(CASE WHEN success THEN 1.0 ELSE 0.0 END),
                   AVG(batch_size), model_name
            FROM embedding_operations 
            WHERE timestamp > ? 
            GROUP BY operation_type, model_name
        ''', (since,))
        
        operation_stats = []
        for row in cursor.fetchall():
            operation_stats.append({
                'operation_type': row[0],
                'count': row[1],
                'avg_time': row[2],
                'success_rate': row[3],
                'avg_batch_size': row[4],
                'model_name': row[5]
            })
        
        # System performance
        cursor.execute('''
            SELECT AVG(cpu_percent), AVG(memory_percent), 
                   AVG(memory_available_gb), COUNT(*)
            FROM system_metrics 
            WHERE timestamp > ?
        ''', (since,))
        
        system_row = cursor.fetchone()
        system_stats = {
            'avg_cpu': system_row[0],
            'avg_memory': system_row[1],
            'avg_memory_available_gb': system_row[2],
            'measurement_count': system_row[3]
        }
        
        # Search performance
        cursor.execute('''
            SELECT COUNT(*), AVG(search_time), AVG(results_count)
            FROM search_operations 
            WHERE timestamp > ?
        ''', (since,))
        
        search_row = cursor.fetchone()
        search_stats = {
            'search_count': search_row[0],
            'avg_search_time': search_row[1],
            'avg_results_count': search_row[2]
        }
        
        return {
            'report_period_hours': hours,
            'generated_at': datetime.now().isoformat(),
            'operation_statistics': operation_stats,
            'system_performance': system_stats,
            'search_performance': search_stats,
            'current_operations': len(self.current_operations),
            'recent_operations': len(self.operation_history)
        }
    
    def export_metrics(self, format: str = 'json', output_path: str = None) -> str:
        """Export metrics in various formats"""
        report = self.generate_performance_report(hours=24)
        
        if output_path is None:
            output_path = f".claude/metrics-export-{datetime.now().strftime('%Y%m%d-%H%M%S')}.{format}"
        
        if format == 'json':
            with open(output_path, 'w') as f:
                json.dump(report, f, indent=2, default=str)
        
        elif format == 'csv' and HAS_MONITORING:
            df = pd.DataFrame(report['operation_statistics'])
            df.to_csv(output_path, index=False)
        
        else:
            raise ValueError(f"Unsupported export format: {format}")
        
        return output_path
    
    def get_real_time_dashboard_data(self) -> Dict[str, Any]:
        """Get data for real-time dashboard"""
        current_metrics = self._capture_system_metrics()
        
        return {
            'timestamp': datetime.now().isoformat(),
            'system_metrics': asdict(current_metrics),
            'active_operations': [
                {
                    'id': op.operation_id,
                    'type': op.operation_type,
                    'duration': time.time() - op.timestamp.timestamp(),
                    'model': op.model_name
                }
                for op in self.current_operations.values()
            ],
            'recent_performance': [
                {
                    'operation_type': op.operation_type,
                    'processing_time': op.processing_time,
                    'success': op.success,
                    'timestamp': op.timestamp.isoformat()
                }
                for op in self.operation_history[-10:]
            ]
        }
    
    def start_prometheus_server(self, port: int = None):
        """Start Prometheus metrics server"""
        if not HAS_MONITORING:
            print("❌ Prometheus monitoring not available")
            return
        
        port = port or self.config.get('prometheus_port', 8000)
        
        try:
            prometheus_client.start_http_server(port, registry=self.registry)
            print(f"📊 Prometheus metrics server started on port {port}")
            print(f"   Metrics available at: http://localhost:{port}/metrics")
        except Exception as e:
            self.logger.error(f"Failed to start Prometheus server: {e}")
    
    def cleanup_old_metrics(self, days: int = None):
        """Clean up old metrics data"""
        days = days or self.config.get('metrics_retention_days', 30)
        cutoff = datetime.now() - timedelta(days=days)
        
        cursor = self.conn.cursor()
        
        # Clean up old operations
        cursor.execute('DELETE FROM embedding_operations WHERE timestamp < ?', (cutoff,))
        ops_deleted = cursor.rowcount
        
        # Clean up old system metrics
        cursor.execute('DELETE FROM system_metrics WHERE timestamp < ?', (cutoff,))
        metrics_deleted = cursor.rowcount
        
        # Clean up old search operations
        cursor.execute('DELETE FROM search_operations WHERE timestamp < ?', (cutoff,))
        searches_deleted = cursor.rowcount
        
        self.conn.commit()
        
        print(f"🧹 Cleaned up old metrics:")
        print(f"   Operations: {ops_deleted}")
        print(f"   System metrics: {metrics_deleted}")
        print(f"   Search operations: {searches_deleted}")

# Global observability instance
_observability_instance = None

def get_observability() -> RAGObservabilitySystem:
    """Get or create global observability instance"""
    global _observability_instance
    if _observability_instance is None:
        _observability_instance = RAGObservabilitySystem()
    return _observability_instance

def track_embedding_operation(operation_type: str, model_name: str, input_text: str = "", batch_size: int = 1):
    """Decorator/context manager for tracking embedding operations"""
    return get_observability().track_operation(operation_type, model_name, input_text, batch_size)

if __name__ == '__main__':
    # Example usage
    obs = RAGObservabilitySystem()
    obs.start_monitoring()
    obs.start_prometheus_server()
    
    # Simulate some operations
    with obs.track_operation('test', 'all-MiniLM-L6-v2', 'test input') as op:
        time.sleep(1)  # Simulate processing
        op.chunk_count = 5
    
    # Generate and display report
    report = obs.generate_performance_report(hours=1)
    print(json.dumps(report, indent=2, default=str))
    
    # Keep monitoring for a while
    try:
        time.sleep(30)
    except KeyboardInterrupt:
        pass
    finally:
        obs.stop_monitoring()