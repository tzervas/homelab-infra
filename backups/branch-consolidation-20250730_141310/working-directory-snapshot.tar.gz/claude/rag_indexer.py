#!/usr/bin/env python3
"""
RAG Context Indexer for Claude Code Subagents

This script creates and maintains an index of project content for RAG-based
context retrieval by Claude Code specialized subagents.

Usage:
    python rag_indexer.py [--update] [--category CATEGORY]
    
Categories: kubernetes, terraform, ansible, python, documentation, all
"""

import json
import logging
import os
import pathlib
import re
import hashlib
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Dict, List, Optional, Set
import argparse
import fnmatch

# Configure logging with user rules
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@dataclass
class DocumentMetadata:
    """Metadata for indexed documents"""
    path: str
    category: str
    file_type: str
    size: int
    last_modified: float
    content_hash: str
    indexed_at: str
    
@dataclass 
class FunctionMetadata:
    """Metadata for extracted functions (per user rules)"""
    name: str
    file_path: str
    line_number: int
    docstring: Optional[str]
    type_hints: Dict[str, str]
    parameters: List[str]
    return_type: Optional[str]
    behavior_description: str

@dataclass
class IndexEntry:
    """Complete index entry for a document"""
    metadata: DocumentMetadata
    content: str
    functions: List[FunctionMetadata]
    keywords: Set[str]
    relationships: List[str]  # Related files/modules

class RAGIndexer:
    """RAG context indexer for Claude Code subagents"""
    
    def __init__(self, project_root: str, config_path: str):
        self.project_root = pathlib.Path(project_root)
        self.config_path = pathlib.Path(config_path)
        self.config = self._load_config()
        self.index_path = self.project_root / ".claude" / "rag_index.json"
        self.metadata_path = self.project_root / ".claude" / "rag_metadata.json"
        
        # Ensure output directory exists (per user rules)
        self.index_path.parent.mkdir(exist_ok=True)
        
    def _load_config(self) -> Dict:
        """Load Claude configuration"""
        try:
            with open(self.config_path, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            logger.error(f"Configuration file not found: {self.config_path}")
            raise
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in config file: {e}")
            raise
    
    def _should_index_file(self, file_path: pathlib.Path) -> bool:
        """Check if file should be indexed based on configuration"""
        if not file_path.is_file():
            return False
            
        # Check exclude patterns
        for exclude_pattern in self.config["ragConfiguration"]["excludePaths"]:
            if fnmatch.fnmatch(str(file_path), exclude_pattern):
                return False
                
        # Check file extension
        file_ext = file_path.suffix.lstrip('.')
        return file_ext in self.config["ragConfiguration"]["indexedFileTypes"]
    
    def _extract_keywords(self, content: str, file_type: str) -> Set[str]:
        """Extract keywords from content based on file type"""
        keywords = set()
        
        # Common technical keywords
        tech_patterns = [
            r'\b(kubernetes|k8s|helm|kubectl)\b',
            r'\b(terraform|tf|hcl)\b', 
            r'\b(ansible|playbook|yaml)\b',
            r'\b(python|py|pip|uv)\b',
            r'\b(docker|container|image)\b',
            r'\b(prometheus|grafana|monitoring)\b',
            r'\b(nginx|ingress|service)\b',
            r'\b(secret|configmap|volume)\b'
        ]
        
        for pattern in tech_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            keywords.update(m.lower() for m in matches)
            
        # Extract resource names from YAML
        if file_type in ['yaml', 'yml']:
            resource_patterns = [
                r'kind:\s*(\w+)',
                r'name:\s*(["\']?)([^"\'\s]+)\1',
                r'namespace:\s*(["\']?)([^"\'\s]+)\1'
            ]
            for pattern in resource_patterns:
                matches = re.findall(pattern, content)
                keywords.update(m[-1] for m in matches if m[-1])
                
        return keywords
    
    def _extract_python_functions(self, content: str, file_path: str) -> List[FunctionMetadata]:
        """Extract Python function metadata (per user rules)"""
        functions = []
        
        # Pattern to match function definitions with optional type hints
        func_pattern = r'def\s+(\w+)\s*\(([^)]*)\)\s*(?:->\s*([^:]+))?\s*:'
        
        for match in re.finditer(func_pattern, content):
            func_name = match.group(1)
            params_str = match.group(2)
            return_type = match.group(3)
            
            # Find line number
            line_num = content[:match.start()].count('\n') + 1
            
            # Extract parameters and type hints
            parameters = []
            type_hints = {}
            
            if params_str.strip():
                param_parts = [p.strip() for p in params_str.split(',')]
                for param_part in param_parts:
                    if ':' in param_part:
                        param_name, param_type = param_part.split(':', 1)
                        param_name = param_name.strip()
                        type_hints[param_name] = param_type.strip()
                        parameters.append(param_name)
                    else:
                        parameters.append(param_part.strip())
            
            # Extract docstring
            docstring_pattern = rf'def\s+{re.escape(func_name)}.*?:\s*(?:"""([^"]*)"""|\'\'\'([^\']*)\'\'\')'
            docstring_match = re.search(docstring_pattern, content, re.DOTALL)
            docstring = docstring_match.group(1) or docstring_match.group(2) if docstring_match else None
            
            # Generate behavior description
            behavior_desc = f"Function {func_name}"
            if docstring:
                behavior_desc += f": {docstring.strip().split('.')[0]}"
            
            functions.append(FunctionMetadata(
                name=func_name,
                file_path=file_path,
                line_number=line_num,
                docstring=docstring,
                type_hints=type_hints,
                parameters=parameters,
                return_type=return_type.strip() if return_type else None,
                behavior_description=behavior_desc
            ))
            
        return functions
    
    def _categorize_file(self, file_path: pathlib.Path) -> str:
        """Categorize file based on path and content"""
        path_str = str(file_path.relative_to(self.project_root))
        
        # Check specialized configurations
        for category, config in self.config["specializedConfigurations"].items():
            for context_path in config["contextPaths"]:
                if path_str.startswith(context_path.rstrip('/')):
                    return category
                    
        # Default categorization
        if file_path.suffix in ['.md', '.txt', '.rst']:
            return 'documentation'
        elif file_path.suffix in ['.py']:
            return 'python'
        elif file_path.suffix in ['.yaml', '.yml'] and 'kubernetes' in path_str:
            return 'kubernetes'
        elif file_path.suffix in ['.tf', '.hcl']:
            return 'terraform'
        else:
            return 'general'
    
    def _index_file(self, file_path: pathlib.Path) -> Optional[IndexEntry]:
        """Index a single file"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                
            # Create metadata
            stat = file_path.stat()
            content_hash = hashlib.sha256(content.encode()).hexdigest()
            
            metadata = DocumentMetadata(
                path=str(file_path.relative_to(self.project_root)),
                category=self._categorize_file(file_path),
                file_type=file_path.suffix.lstrip('.'),
                size=stat.st_size,
                last_modified=stat.st_mtime,
                content_hash=content_hash,
                indexed_at=datetime.now().isoformat()
            )
            
            # Extract keywords
            keywords = self._extract_keywords(content, metadata.file_type)
            
            # Extract function metadata for Python files
            functions = []
            if metadata.file_type == 'py':
                functions = self._extract_python_functions(content, metadata.path)
            
            # Find relationships (simplified)
            relationships = []
            if 'import' in content:
                import_matches = re.findall(r'from\s+([^\s]+)\s+import|import\s+([^\s]+)', content)
                for match in import_matches:
                    module = match[0] or match[1]
                    if module and not module.startswith('.'):
                        relationships.append(module)
            
            return IndexEntry(
                metadata=metadata,
                content=content,
                functions=functions,
                keywords=keywords,
                relationships=relationships
            )
            
        except Exception as e:
            logger.error(f"Error indexing {file_path}: {e}")
            return None
    
    def build_index(self, category_filter: Optional[str] = None) -> Dict:
        """Build complete RAG index"""
        logger.info("Building RAG index...")
        
        index = {
            "version": "1.0",
            "created_at": datetime.now().isoformat(),
            "project_root": str(self.project_root),
            "categories": {},
            "function_metadata": [],
            "keyword_map": {},
            "file_relationships": {}
        }
        
        # Process index paths
        for index_path in self.config["ragConfiguration"]["indexPaths"]:
            path_obj = self.project_root / index_path
            
            if path_obj.is_file():
                files_to_process = [path_obj]
            elif path_obj.is_dir():
                files_to_process = []
                for pattern in ["**/*"]:
                    files_to_process.extend(path_obj.glob(pattern))
            else:
                continue
                
            for file_path in files_to_process:
                if not self._should_index_file(file_path):
                    continue
                    
                entry = self._index_file(file_path)
                if not entry:
                    continue
                    
                # Filter by category if specified
                if category_filter and entry.metadata.category != category_filter:
                    continue
                
                category = entry.metadata.category
                if category not in index["categories"]:
                    index["categories"][category] = []
                    
                # Store entry data
                entry_data = {
                    "metadata": asdict(entry.metadata),
                    "content_preview": entry.content[:500] + "..." if len(entry.content) > 500 else entry.content,
                    "keywords": list(entry.keywords),
                    "relationships": entry.relationships
                }
                
                index["categories"][category].append(entry_data)
                
                # Add function metadata
                for func in entry.functions:
                    index["function_metadata"].append(asdict(func))
                
                # Update keyword map
                for keyword in entry.keywords:
                    if keyword not in index["keyword_map"]:
                        index["keyword_map"][keyword] = []
                    index["keyword_map"][keyword].append(entry.metadata.path)
                
                # Store relationships
                if entry.relationships:
                    index["file_relationships"][entry.metadata.path] = entry.relationships
        
        return index
    
    def save_index(self, index: Dict):
        """Save index to disk (per user rules - not version controlled)"""
        try:
            with open(self.index_path, 'w') as f:
                json.dump(index, f, indent=2)
            logger.info(f"Index saved to {self.index_path}")
            
            # Create metadata summary
            metadata = {
                "total_files": sum(len(files) for files in index["categories"].values()),
                "categories": {cat: len(files) for cat, files in index["categories"].items()},
                "total_functions": len(index["function_metadata"]),
                "total_keywords": len(index["keyword_map"]),
                "last_updated": datetime.now().isoformat()
            }
            
            with open(self.metadata_path, 'w') as f:
                json.dump(metadata, f, indent=2)
            logger.info(f"Metadata saved to {self.metadata_path}")
            
        except Exception as e:
            logger.error(f"Error saving index: {e}")
            raise

def main():
    """CLI entry point"""
    parser = argparse.ArgumentParser(description="RAG Context Indexer for Claude Code")
    parser.add_argument('--update', action='store_true', help='Update existing index')
    parser.add_argument('--category', choices=['kubernetes', 'terraform', 'ansible', 'python', 'documentation', 'all'], 
                       default='all', help='Category to index')
    
    args = parser.parse_args()
    
    # Get project root and config paths
    project_root = "/home/vector_weight/Documents/projects/homelab/homelab-infra"
    config_path = os.path.join(project_root, ".claude", "config.json")
    
    try:
        # Initialize indexer
        indexer = RAGIndexer(project_root, config_path)
        
        # Build index
        category_filter = None if args.category == 'all' else args.category
        index = indexer.build_index(category_filter)
        
        # Save index
        indexer.save_index(index)
        
        logger.info("RAG index build completed successfully")
        logger.info(f"Indexed {sum(len(files) for files in index['categories'].values())} files")
        logger.info(f"Extracted {len(index['function_metadata'])} functions")
        logger.info(f"Found {len(index['keyword_map'])} unique keywords")
        
    except Exception as e:
        logger.error(f"Index build failed: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    exit(main())
