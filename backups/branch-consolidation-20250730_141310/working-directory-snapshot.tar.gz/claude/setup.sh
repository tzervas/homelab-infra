#!/bin/bash
# Claude Code RAG System Setup Script
# Installs dependencies and configures the system

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

# Colors for output
readonly GREEN='\033[0;32m'
readonly BLUE='\033[0;34m'
readonly YELLOW='\033[1;33m'
readonly RED='\033[0;31m'
readonly NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

echo "🚀 Claude Code RAG System Setup"
echo "==============================="

# Step 1: Check Python
log_info "Checking Python installation..."
if command -v python3 >/dev/null 2>&1; then
    PYTHON_VERSION=$(python3 --version)
    log_success "Python found: $PYTHON_VERSION"
else
    log_error "Python 3 is required but not found"
    exit 1
fi

# Step 2: Install dependencies
log_info "Installing Python dependencies..."
if [[ -f "$SCRIPT_DIR/requirements.txt" ]]; then
    pip3 install -r "$SCRIPT_DIR/requirements.txt" --user --quiet
    log_success "Dependencies installed"
else
    log_warning "requirements.txt not found - installing minimal dependencies"
    pip3 install sentence-transformers faiss-cpu numpy torch --user --quiet
fi

# Step 3: Setup directories
log_info "Setting up directories..."
mkdir -p "$SCRIPT_DIR/logs"
mkdir -p "$SCRIPT_DIR/data"
chmod +x "$SCRIPT_DIR"/*.sh 2>/dev/null || true
chmod +x "$SCRIPT_DIR"/*.py 2>/dev/null || true
log_success "Directories configured"

# Step 4: Test system
log_info "Testing system components..."

# Test Python imports
cd "$PROJECT_ROOT"
export PYTHONPATH="$SCRIPT_DIR:$PYTHONPATH"

if python3 -c "import sys; sys.path.insert(0, '$SCRIPT_DIR'); import local_rag_setup; print('✅ RAG system import successful')" 2>/dev/null; then
    log_success "Core RAG components working"
else
    log_warning "Some RAG components may not be fully functional"
fi

# Step 5: Create symbolic links for easy access
log_info "Creating convenience links..."
ln -sf "$SCRIPT_DIR/rag-integration.py" "$PROJECT_ROOT/rag" 2>/dev/null || true
ln -sf "$SCRIPT_DIR/test-complete-system.py" "$PROJECT_ROOT/test-rag" 2>/dev/null || true

# Step 6: Configuration check
log_info "Checking configuration..."
if [[ -f "$SCRIPT_DIR/rag-config.json" ]]; then
    if python3 -c "import json; json.load(open('$SCRIPT_DIR/rag-config.json'))" 2>/dev/null; then
        log_success "Configuration file is valid"
    else
        log_error "Configuration file is corrupted"
        exit 1
    fi
else
    log_warning "No configuration file found - will use defaults"
fi

# Step 7: Final system check
log_info "Running final system check..."
cd "$PROJECT_ROOT"
export PYTHONPATH="$SCRIPT_DIR:$PYTHONPATH"

if python3 -c "
import sys
sys.path.insert(0, '$SCRIPT_DIR')
try:
    from local_rag_setup import LocalRAGSystem
    from rag_observability import RAGObservabilitySystem  
    print('✅ All core components available')
except ImportError as e:
    print(f'⚠️  Some components unavailable: {e}')
" 2>/dev/null; then
    log_success "System is ready for use"
else
    log_warning "System partially ready - some features may be limited"
fi

echo ""
echo "🎉 Setup Complete!"
echo ""
echo "Next steps:"
echo "1. Index your project: ./.claude/rag-cli.sh auto-index"
echo "2. Search for context: ./.claude/rag-cli.sh search 'your query'"
echo "3. Run system demo: ./.claude/demo.sh"
echo "4. Test full system: python3 .claude/test-complete-system.py"
echo ""
echo "📚 Documentation: .claude/README.md"