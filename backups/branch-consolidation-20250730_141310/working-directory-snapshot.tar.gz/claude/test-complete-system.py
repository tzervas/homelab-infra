#!/usr/bin/env python3
"""
Complete RAG System Test Suite
Tests the entire integrated RAG system with observability and GPU safety
"""

import os
import sys
import time
import tempfile
from pathlib import Path
from typing import Dict, Any

# Add current directory to path for imports
sys.path.insert(0, str(Path(__file__).parent))

def test_component_imports():
    """Test that all components can be imported"""
    print("🧪 Testing Component Imports")
    print("-" * 30)
    
    components = {
        'local_rag_setup': ['LocalRAGSystem', 'GPUMonitor'],
        'rag_observability': ['RAGObservabilitySystem', 'get_observability'],
        'rag_integration': ['IntegratedRAGSystem']
    }
    
    results = {}
    
    for module_name, classes in components.items():
        try:
            module = __import__(module_name)
            for class_name in classes:
                if hasattr(module, class_name):
                    print(f"   ✅ {module_name}.{class_name}")
                    results[f"{module_name}.{class_name}"] = True
                else:
                    print(f"   ❌ {module_name}.{class_name} - not found")
                    results[f"{module_name}.{class_name}"] = False
        except ImportError as e:
            print(f"   ❌ {module_name} - import failed: {e}")
            for class_name in classes:
                results[f"{module_name}.{class_name}"] = False
    
    return results

def test_gpu_safety():
    """Test GPU safety monitoring"""
    print("\n🛡️  Testing GPU Safety System")
    print("-" * 30)
    
    try:
        from local_rag_setup import GPUMonitor
        
        monitor = GPUMonitor()
        
        # Test safety check
        is_safe = monitor.check_gpu_safety()
        print(f"   📊 GPU safety check: {'✅ Safe' if is_safe else '⚠️ Unsafe'}")
        
        # Test GPU stats
        stats = monitor.get_gpu_stats()
        if stats.get('gpu_available'):
            print(f"   🖥️  GPU count: {stats.get('gpu_count', 0)}")
            for gpu in stats.get('gpus', []):
                print(f"      GPU {gpu['id']}: {gpu['name']} ({gpu['temperature']}°C, {gpu['memory_util']*100:.1f}% mem)")
        else:
            print("   🖥️  No GPU available - CPU mode")
        
        # Test batch size calculation
        batch_size = monitor.get_optimal_batch_size()
        print(f"   📦 Optimal batch size: {batch_size}")
        
        return True
        
    except Exception as e:
        print(f"   ❌ GPU safety test failed: {e}")
        return False

def test_observability_system():
    """Test observability system"""
    print("\n📊 Testing Observability System")
    print("-" * 30)
    
    try:
        from rag_observability import RAGObservabilitySystem
        
        # Create temporary config
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            config = {
                "metrics_retention_days": 1,
                "detailed_logging": True,
                "monitoring_interval": 1
            }
            import json
            json.dump(config, f)
            config_path = f.name
        
        try:
            obs = RAGObservabilitySystem(config_path)
            
            # Test operation tracking
            with obs.track_operation('test', 'test-model', 'test input') as op:
                time.sleep(0.1)  # Simulate work
                op.chunk_count = 5
            
            print("   ✅ Operation tracking works")
            
            # Test background monitoring
            obs.start_monitoring()
            time.sleep(2)  # Let it collect some metrics
            obs.stop_monitoring()
            
            print("   ✅ Background monitoring works")
            
            # Test performance report
            report = obs.generate_performance_report(hours=1)
            print(f"   📈 Generated report with {len(report.get('operation_statistics', []))} operation types")
            
            # Test real-time data
            dashboard_data = obs.get_real_time_dashboard_data()
            print(f"   📊 Real-time dashboard data available")
            
            return True
            
        finally:
            os.unlink(config_path)
        
    except Exception as e:
        print(f"   ❌ Observability test failed: {e}")
        return False

def test_integrated_system():
    """Test the complete integrated system"""
    print("\n🚀 Testing Integrated RAG System")
    print("-" * 30)
    
    try:
        from rag_integration import IntegratedRAGSystem
        
        # Test system initialization
        with IntegratedRAGSystem().session() as rag:
            print("   ✅ System initialization successful")
            
            # Test health check
            health = rag.health_check()
            healthy_components = sum(1 for status in health.values() if status)
            total_components = len(health)
            print(f"   🏥 Health check: {healthy_components}/{total_components} components healthy")
            
            for component, status in health.items():
                status_icon = "✅" if status else "⚠️"
                print(f"      {status_icon} {component}")
            
            # Test stats collection
            stats = rag.get_comprehensive_stats()
            stats_sections = len([k for k in stats.keys() if stats[k]])
            print(f"   📊 Statistics: {stats_sections} sections available")
            
            # Test search (if embeddings are available)
            if health.get('embeddings_available', False):
                results = rag.search_with_observability("test query", max_results=1)
                print(f"   🔍 Search test: {len(results)} results returned")
                
                # Test context generation
                context = rag.generate_optimized_context("test context")
                print(f"   📄 Context generation: {len(context)} characters generated")
            else:
                print("   ⚠️  Skipping search tests - embeddings not available")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Integrated system test failed: {e}")
        return False

def test_configuration_loading():
    """Test configuration loading and validation"""
    print("\n⚙️  Testing Configuration System")
    print("-" * 30)
    
    try:
        # Test with existing config
        config_path = ".claude/rag-config.json"
        if Path(config_path).exists():
            with open(config_path, 'r') as f:
                import json
                config = json.load(f)
            print(f"   ✅ Loaded config with {len(config)} sections")
            
            # Validate key sections
            required_sections = ['embedding_config', 'token_optimization', 'codebase_profiles']
            for section in required_sections:
                if section in config:
                    print(f"      ✅ {section}")
                else:
                    print(f"      ⚠️  {section} - missing")
        else:
            print("   ⚠️  No config file found - will use defaults")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Configuration test failed: {e}")
        return False

def test_cli_integration():
    """Test CLI components"""
    print("\n🖥️  Testing CLI Integration")
    print("-" * 30)
    
    cli_scripts = [
        '.claude/rag-cli.sh',
        '.claude/demo.sh'
    ]
    
    results = {}
    
    for script in cli_scripts:
        if Path(script).exists():
            print(f"   ✅ {script} exists")
            results[script] = True
            
            # Check if executable
            if os.access(script, os.X_OK):
                print(f"      ✅ executable")
            else:
                print(f"      ⚠️  not executable")
        else:
            print(f"   ❌ {script} missing")
            results[script] = False
    
    return all(results.values())

def run_complete_test_suite():
    """Run the complete test suite"""
    print("🧪 Complete RAG System Test Suite")
    print("=" * 50)
    print(f"Running at: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Python version: {sys.version}")
    print(f"Working directory: {os.getcwd()}")
    print()
    
    test_results = {}
    
    # Run all tests
    tests = [
        ("Component Imports", test_component_imports),
        ("GPU Safety", test_gpu_safety),
        ("Observability System", test_observability_system),
        ("Configuration Loading", test_configuration_loading),
        ("CLI Integration", test_cli_integration),
        ("Integrated System", test_integrated_system)
    ]
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            test_results[test_name] = result
        except Exception as e:
            print(f"\n❌ {test_name} failed with exception: {e}")
            test_results[test_name] = False
    
    # Summary
    print("\n" + "=" * 50)
    print("🎯 Test Suite Summary")
    print("-" * 20)
    
    passed = sum(1 for result in test_results.values() if result)
    total = len(test_results)
    
    for test_name, result in test_results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"   {status} {test_name}")
    
    print(f"\n📊 Overall Result: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! System is ready for use.")
        return True
    else:
        print("⚠️  Some tests failed. Check output above for details.")
        return False

def main():
    """Main test runner"""
    success = run_complete_test_suite()
    
    if success:
        print("\n🚀 System Status: READY")
        print("\nNext steps:")
        print("1. Run: ./.claude/rag-cli.sh setup")
        print("2. Run: ./.claude/rag-cli.sh auto-index")
        print("3. Run: ./.claude/rag-cli.sh search 'your query'")
        print("4. Or try: python3 .claude/rag-integration.py demo")
        return 0
    else:
        print("\n❌ System Status: NEEDS ATTENTION")
        print("\nTroubleshooting:")
        print("1. Install dependencies: pip install -r .claude/requirements.txt") 
        print("2. Check configuration: .claude/rag-config.json")
        print("3. Verify file permissions: chmod +x .claude/*.sh")
        return 1

if __name__ == '__main__':
    sys.exit(main())