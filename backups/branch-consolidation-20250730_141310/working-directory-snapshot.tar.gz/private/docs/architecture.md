# Homelab Infrastructure Architecture

## Overview

This document outlines the system design and component relationships for the homelab infrastructure project. The architecture is built around Kubernetes (k3s) for container orchestration, with supporting components for storage, networking, monitoring, and security.

## Core Components

### 1. Kubernetes Layer (k3s)

- **Version**: v1.30.6+k3s1
- **Configuration**:
  - Disabled built-in Traefik and servicelb
  - Custom TLS SAN entries
  - Node taints for workload isolation
  - Optimized resource allocation

### 2. Storage Infrastructure

- **Primary**: Longhorn (v1.7.1)
  - Distributed block storage
  - Volume replication
  - Backup/restore capabilities

### 3. Networking Stack

- **Load Balancer**: MetalLB (v0.14.8)
  - Layer 2 mode
  - IP range: 192.168.25.x
- **Ingress Controller**: ingress-nginx (v4.11.2)
  - TLS termination
  - Path-based routing
  - Rate limiting

### 4. Monitoring & Observability

- **Metrics**: Prometheus Stack (v61.7.2)
  - Prometheus server
  - Node exporters
  - Alert manager
- **Logging**: Loki (v6.6.4)
- **Visualization**: Grafana (v8.4.2)

## Security Architecture

### 1. Network Security

- Default deny-all network policies
- Segmented namespaces
- Ingress rules based on necessity
- TLS everywhere

### 2. Access Control

- RBAC with least privilege
- Service account segregation
- Pod security standards enforcement

### 3. Secret Management

- Environment variables for sensitive data
- Separate .env files per environment
- Potential integration with external secret management

## Component Relationships

```mermaid
graph TD
    A[External Traffic] --> B[MetalLB]
    B --> C[ingress-nginx]
    C --> D[K3s Cluster]
    D --> E[Application Pods]
    E --> F[Longhorn Storage]
    D --> G[Monitoring Stack]
    G --> H[Grafana]
    G --> I[Prometheus]
    G --> J[Loki]
```

## Deployment Strategy

- Helm charts for package management
- Helmfile for orchestration
- Environment-specific values
- Version pinning for stability

## Scaling Considerations

- Node resource allocation
- Storage capacity planning
- Backup strategies
- High availability configurations

## Future Expansion

- Potential additional nodes
- Backup node considerations
- DR planning
- Service mesh integration
